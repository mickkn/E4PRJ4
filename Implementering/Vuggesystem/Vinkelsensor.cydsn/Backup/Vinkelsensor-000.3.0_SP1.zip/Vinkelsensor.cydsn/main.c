/*******************************************************************************
* File Name: main.c
*
* Version: 1.00
*
* Description:
*  
*
********************************************************************************
* 
*******************************************************************************/

#include <device.h>
#include <stdio.h>

/* Macro definitions */
#define DEBUG 1

#define FS 100
#define TS_MILLI 10 

/* Global variables */
volatile uint8 accReady = 0, gyroReady = 0;
volatile int16 accData[2] = {0, 0}, gyroData = 0;
float gyroAng = 0, accAng = 0, estAng = 0;

/* Function prototypes */
CY_ISR(accDataReadyInterrupt);
CY_ISR(gyroDataReadyInterrupt);

/*******************************************************************************
* Function Name: main
********************************************************************************
*
* Summary:
*  Performs the following tasks:
*
*******************************************************************************/
int main()
{
    /* Start the Components */
    UART_Start();
    I2C_Start();
    ACC_DR_INT_StartEx(accDataReadyInterrupt);
    GYRO_DR_INT_StartEx(gyroDataReadyInterrupt);
    
    /* Enable global interrupts */
    CyGlobalIntEnable;
    
    /*print opening msg*/
    UART_UartPutString("Hello World\n");
    
    /*Data processing loop*/
    while(1){
        while(accReady == 0 || gyroReady == 0);
        
        gyroAng += gyroData * TS_MILLI;  // unit off angle is 2^-14 deg/Lsb 
        if(gyroAng < -2949120) gyroAng += 5898240; // if less than -180, add 360
        if(gyroAng > 2949120) gyroAng -= 5898240; // if larger than 180, subtract 360
        
        int forceMagnitudeApprox = abs(accData[0]) + abs(accData[1]) + abs(accData[2]);
    if (forceMagnitudeApprox > 8192 && forceMagnitudeApprox < 32768)
    {
	// Turning around the X axis results in a vector on the Y-axis
        pitchAcc = atan2f((float)accData[1], (float)accData[2]) * 180 / M_PI;
        *pitch = *pitch * 0.98 + pitchAcc * 0.02;
 
	// Turning around the Y axis results in a vector on the X-axis
        rollAcc = atan2f((float)accData[0], (float)accData[2]) * 180 / M_PI;
        *roll = *roll * 0.98 + rollAcc * 0.02;
    }
} 
    }
    return 0;
}

CY_ISR(accDataReadyInterrupt)
{
    //make necessary i2c reads from accellerometer.
    accReady = 1;
}

CY_ISR(gyroDataReadyInterrupt)
{
    //make necessary i2c reads from accellerometer.
    gyroReady = 1;
}
                    
    
/* [] END OF FILE */
