/*******************************************************************************
* File Name: loopTimer.h
* Version 2.70
*
*  Description:
*     Contains the function prototypes and constants available to the timer
*     user module.
*
*   Note:
*     None
*
********************************************************************************
* Copyright 2008-2014, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
********************************************************************************/

#if !defined(CY_Timer_v2_60_loopTimer_H)
#define CY_Timer_v2_60_loopTimer_H

#include "cytypes.h"
#include "cyfitter.h"
#include "CyLib.h" /* For CyEnterCriticalSection() and CyExitCriticalSection() functions */

extern uint8 loopTimer_initVar;

/* Check to see if required defines such as CY_PSOC5LP are available */
/* They are defined starting with cy_boot v3.0 */
#if !defined (CY_PSOC5LP)
    #error Component Timer_v2_70 requires cy_boot v3.0 or later
#endif /* (CY_ PSOC5LP) */


/**************************************
*           Parameter Defaults
**************************************/

#define loopTimer_Resolution                 8u
#define loopTimer_UsingFixedFunction         0u
#define loopTimer_UsingHWCaptureCounter      0u
#define loopTimer_SoftwareCaptureMode        0u
#define loopTimer_SoftwareTriggerMode        0u
#define loopTimer_UsingHWEnable              0u
#define loopTimer_EnableTriggerMode          0u
#define loopTimer_InterruptOnCaptureCount    0u
#define loopTimer_RunModeUsed                0u
#define loopTimer_ControlRegRemoved          0u

#if defined(loopTimer_TimerUDB_sCTRLReg_SyncCtl_ctrlreg__CONTROL_REG)
    #define loopTimer_UDB_CONTROL_REG_REMOVED            (0u)
#elif  (loopTimer_UsingFixedFunction)
    #define loopTimer_UDB_CONTROL_REG_REMOVED            (0u)
#else 
    #define loopTimer_UDB_CONTROL_REG_REMOVED            (1u)
#endif /* End loopTimer_TimerUDB_sCTRLReg_SyncCtl_ctrlreg__CONTROL_REG */


/***************************************
*       Type defines
***************************************/


/**************************************************************************
 * Sleep Wakeup Backup structure for Timer Component
 *************************************************************************/
typedef struct
{
    uint8 TimerEnableState;
    #if(!loopTimer_UsingFixedFunction)

        uint8 TimerUdb;
        uint8 InterruptMaskValue;
        #if (loopTimer_UsingHWCaptureCounter)
            uint8 TimerCaptureCounter;
        #endif /* variable declarations for backing up non retention registers in CY_UDB_V1 */

        #if (!loopTimer_UDB_CONTROL_REG_REMOVED)
            uint8 TimerControlRegister;
        #endif /* variable declaration for backing up enable state of the Timer */
    #endif /* define backup variables only for UDB implementation. Fixed function registers are all retention */

}loopTimer_backupStruct;


/***************************************
*       Function Prototypes
***************************************/

void    loopTimer_Start(void) ;
void    loopTimer_Stop(void) ;

void    loopTimer_SetInterruptMode(uint8 interruptMode) ;
uint8   loopTimer_ReadStatusRegister(void) ;
/* Deprecated function. Do not use this in future. Retained for backward compatibility */
#define loopTimer_GetInterruptSource() loopTimer_ReadStatusRegister()

#if(!loopTimer_UDB_CONTROL_REG_REMOVED)
    uint8   loopTimer_ReadControlRegister(void) ;
    void    loopTimer_WriteControlRegister(uint8 control) ;
#endif /* (!loopTimer_UDB_CONTROL_REG_REMOVED) */

uint8  loopTimer_ReadPeriod(void) ;
void    loopTimer_WritePeriod(uint8 period) ;
uint8  loopTimer_ReadCounter(void) ;
void    loopTimer_WriteCounter(uint8 counter) ;
uint8  loopTimer_ReadCapture(void) ;
void    loopTimer_SoftwareCapture(void) ;

#if(!loopTimer_UsingFixedFunction) /* UDB Prototypes */
    #if (loopTimer_SoftwareCaptureMode)
        void    loopTimer_SetCaptureMode(uint8 captureMode) ;
    #endif /* (!loopTimer_UsingFixedFunction) */

    #if (loopTimer_SoftwareTriggerMode)
        void    loopTimer_SetTriggerMode(uint8 triggerMode) ;
    #endif /* (loopTimer_SoftwareTriggerMode) */

    #if (loopTimer_EnableTriggerMode)
        void    loopTimer_EnableTrigger(void) ;
        void    loopTimer_DisableTrigger(void) ;
    #endif /* (loopTimer_EnableTriggerMode) */


    #if(loopTimer_InterruptOnCaptureCount)
        void    loopTimer_SetInterruptCount(uint8 interruptCount) ;
    #endif /* (loopTimer_InterruptOnCaptureCount) */

    #if (loopTimer_UsingHWCaptureCounter)
        void    loopTimer_SetCaptureCount(uint8 captureCount) ;
        uint8   loopTimer_ReadCaptureCount(void) ;
    #endif /* (loopTimer_UsingHWCaptureCounter) */

    void loopTimer_ClearFIFO(void) ;
#endif /* UDB Prototypes */

/* Sleep Retention APIs */
void loopTimer_Init(void)          ;
void loopTimer_Enable(void)        ;
void loopTimer_SaveConfig(void)    ;
void loopTimer_RestoreConfig(void) ;
void loopTimer_Sleep(void)         ;
void loopTimer_Wakeup(void)        ;


/***************************************
*   Enumerated Types and Parameters
***************************************/

/* Enumerated Type B_Timer__CaptureModes, Used in Capture Mode */
#define loopTimer__B_TIMER__CM_NONE 0
#define loopTimer__B_TIMER__CM_RISINGEDGE 1
#define loopTimer__B_TIMER__CM_FALLINGEDGE 2
#define loopTimer__B_TIMER__CM_EITHEREDGE 3
#define loopTimer__B_TIMER__CM_SOFTWARE 4



/* Enumerated Type B_Timer__TriggerModes, Used in Trigger Mode */
#define loopTimer__B_TIMER__TM_NONE 0x00u
#define loopTimer__B_TIMER__TM_RISINGEDGE 0x04u
#define loopTimer__B_TIMER__TM_FALLINGEDGE 0x08u
#define loopTimer__B_TIMER__TM_EITHEREDGE 0x0Cu
#define loopTimer__B_TIMER__TM_SOFTWARE 0x10u


/***************************************
*    Initialial Parameter Constants
***************************************/

#define loopTimer_INIT_PERIOD             199u
#define loopTimer_INIT_CAPTURE_MODE       ((uint8)((uint8)0u << loopTimer_CTRL_CAP_MODE_SHIFT))
#define loopTimer_INIT_TRIGGER_MODE       ((uint8)((uint8)0u << loopTimer_CTRL_TRIG_MODE_SHIFT))
#if (loopTimer_UsingFixedFunction)
    #define loopTimer_INIT_INTERRUPT_MODE (((uint8)((uint8)0u << loopTimer_STATUS_TC_INT_MASK_SHIFT)) | \
                                                  ((uint8)((uint8)0 << loopTimer_STATUS_CAPTURE_INT_MASK_SHIFT)))
#else
    #define loopTimer_INIT_INTERRUPT_MODE (((uint8)((uint8)0u << loopTimer_STATUS_TC_INT_MASK_SHIFT)) | \
                                                 ((uint8)((uint8)0 << loopTimer_STATUS_CAPTURE_INT_MASK_SHIFT)) | \
                                                 ((uint8)((uint8)0 << loopTimer_STATUS_FIFOFULL_INT_MASK_SHIFT)))
#endif /* (loopTimer_UsingFixedFunction) */
#define loopTimer_INIT_CAPTURE_COUNT      (2u)
#define loopTimer_INIT_INT_CAPTURE_COUNT  ((uint8)((uint8)(1u - 1u) << loopTimer_CTRL_INTCNT_SHIFT))


/***************************************
*           Registers
***************************************/

#if (loopTimer_UsingFixedFunction) /* Implementation Specific Registers and Register Constants */


    /***************************************
    *    Fixed Function Registers
    ***************************************/

    #define loopTimer_STATUS         (*(reg8 *) loopTimer_TimerHW__SR0 )
    /* In Fixed Function Block Status and Mask are the same register */
    #define loopTimer_STATUS_MASK    (*(reg8 *) loopTimer_TimerHW__SR0 )
    #define loopTimer_CONTROL        (*(reg8 *) loopTimer_TimerHW__CFG0)
    #define loopTimer_CONTROL2       (*(reg8 *) loopTimer_TimerHW__CFG1)
    #define loopTimer_CONTROL2_PTR   ( (reg8 *) loopTimer_TimerHW__CFG1)
    #define loopTimer_RT1            (*(reg8 *) loopTimer_TimerHW__RT1)
    #define loopTimer_RT1_PTR        ( (reg8 *) loopTimer_TimerHW__RT1)

    #if (CY_PSOC3 || CY_PSOC5LP)
        #define loopTimer_CONTROL3       (*(reg8 *) loopTimer_TimerHW__CFG2)
        #define loopTimer_CONTROL3_PTR   ( (reg8 *) loopTimer_TimerHW__CFG2)
    #endif /* (CY_PSOC3 || CY_PSOC5LP) */
    #define loopTimer_GLOBAL_ENABLE  (*(reg8 *) loopTimer_TimerHW__PM_ACT_CFG)
    #define loopTimer_GLOBAL_STBY_ENABLE  (*(reg8 *) loopTimer_TimerHW__PM_STBY_CFG)

    #define loopTimer_CAPTURE_LSB         (* (reg16 *) loopTimer_TimerHW__CAP0 )
    #define loopTimer_CAPTURE_LSB_PTR       ((reg16 *) loopTimer_TimerHW__CAP0 )
    #define loopTimer_PERIOD_LSB          (* (reg16 *) loopTimer_TimerHW__PER0 )
    #define loopTimer_PERIOD_LSB_PTR        ((reg16 *) loopTimer_TimerHW__PER0 )
    #define loopTimer_COUNTER_LSB         (* (reg16 *) loopTimer_TimerHW__CNT_CMP0 )
    #define loopTimer_COUNTER_LSB_PTR       ((reg16 *) loopTimer_TimerHW__CNT_CMP0 )


    /***************************************
    *    Register Constants
    ***************************************/

    /* Fixed Function Block Chosen */
    #define loopTimer_BLOCK_EN_MASK                     loopTimer_TimerHW__PM_ACT_MSK
    #define loopTimer_BLOCK_STBY_EN_MASK                loopTimer_TimerHW__PM_STBY_MSK

    /* Control Register Bit Locations */
    /* Interrupt Count - Not valid for Fixed Function Block */
    #define loopTimer_CTRL_INTCNT_SHIFT                  0x00u
    /* Trigger Polarity - Not valid for Fixed Function Block */
    #define loopTimer_CTRL_TRIG_MODE_SHIFT               0x00u
    /* Trigger Enable - Not valid for Fixed Function Block */
    #define loopTimer_CTRL_TRIG_EN_SHIFT                 0x00u
    /* Capture Polarity - Not valid for Fixed Function Block */
    #define loopTimer_CTRL_CAP_MODE_SHIFT                0x00u
    /* Timer Enable - As defined in Register Map, part of TMRX_CFG0 register */
    #define loopTimer_CTRL_ENABLE_SHIFT                  0x00u

    /* Control Register Bit Masks */
    #define loopTimer_CTRL_ENABLE                        ((uint8)((uint8)0x01u << loopTimer_CTRL_ENABLE_SHIFT))

    /* Control2 Register Bit Masks */
    /* As defined in Register Map, Part of the TMRX_CFG1 register */
    #define loopTimer_CTRL2_IRQ_SEL_SHIFT                 0x00u
    #define loopTimer_CTRL2_IRQ_SEL                      ((uint8)((uint8)0x01u << loopTimer_CTRL2_IRQ_SEL_SHIFT))

    #if (CY_PSOC5A)
        /* Use CFG1 Mode bits to set run mode */
        /* As defined by Verilog Implementation */
        #define loopTimer_CTRL_MODE_SHIFT                 0x01u
        #define loopTimer_CTRL_MODE_MASK                 ((uint8)((uint8)0x07u << loopTimer_CTRL_MODE_SHIFT))
    #endif /* (CY_PSOC5A) */
    #if (CY_PSOC3 || CY_PSOC5LP)
        /* Control3 Register Bit Locations */
        #define loopTimer_CTRL_RCOD_SHIFT        0x02u
        #define loopTimer_CTRL_ENBL_SHIFT        0x00u
        #define loopTimer_CTRL_MODE_SHIFT        0x00u

        /* Control3 Register Bit Masks */
        #define loopTimer_CTRL_RCOD_MASK  ((uint8)((uint8)0x03u << loopTimer_CTRL_RCOD_SHIFT)) /* ROD and COD bit masks */
        #define loopTimer_CTRL_ENBL_MASK  ((uint8)((uint8)0x80u << loopTimer_CTRL_ENBL_SHIFT)) /* HW_EN bit mask */
        #define loopTimer_CTRL_MODE_MASK  ((uint8)((uint8)0x03u << loopTimer_CTRL_MODE_SHIFT)) /* Run mode bit mask */

        #define loopTimer_CTRL_RCOD       ((uint8)((uint8)0x03u << loopTimer_CTRL_RCOD_SHIFT))
        #define loopTimer_CTRL_ENBL       ((uint8)((uint8)0x80u << loopTimer_CTRL_ENBL_SHIFT))
    #endif /* (CY_PSOC3 || CY_PSOC5LP) */

    /*RT1 Synch Constants: Applicable for PSoC3 and PSoC5LP */
    #define loopTimer_RT1_SHIFT                       0x04u
    /* Sync TC and CMP bit masks */
    #define loopTimer_RT1_MASK                        ((uint8)((uint8)0x03u << loopTimer_RT1_SHIFT))
    #define loopTimer_SYNC                            ((uint8)((uint8)0x03u << loopTimer_RT1_SHIFT))
    #define loopTimer_SYNCDSI_SHIFT                   0x00u
    /* Sync all DSI inputs with Mask  */
    #define loopTimer_SYNCDSI_MASK                    ((uint8)((uint8)0x0Fu << loopTimer_SYNCDSI_SHIFT))
    /* Sync all DSI inputs */
    #define loopTimer_SYNCDSI_EN                      ((uint8)((uint8)0x0Fu << loopTimer_SYNCDSI_SHIFT))

    #define loopTimer_CTRL_MODE_PULSEWIDTH            ((uint8)((uint8)0x01u << loopTimer_CTRL_MODE_SHIFT))
    #define loopTimer_CTRL_MODE_PERIOD                ((uint8)((uint8)0x02u << loopTimer_CTRL_MODE_SHIFT))
    #define loopTimer_CTRL_MODE_CONTINUOUS            ((uint8)((uint8)0x00u << loopTimer_CTRL_MODE_SHIFT))

    /* Status Register Bit Locations */
    /* As defined in Register Map, part of TMRX_SR0 register */
    #define loopTimer_STATUS_TC_SHIFT                 0x07u
    /* As defined in Register Map, part of TMRX_SR0 register, Shared with Compare Status */
    #define loopTimer_STATUS_CAPTURE_SHIFT            0x06u
    /* As defined in Register Map, part of TMRX_SR0 register */
    #define loopTimer_STATUS_TC_INT_MASK_SHIFT        (loopTimer_STATUS_TC_SHIFT - 0x04u)
    /* As defined in Register Map, part of TMRX_SR0 register, Shared with Compare Status */
    #define loopTimer_STATUS_CAPTURE_INT_MASK_SHIFT   (loopTimer_STATUS_CAPTURE_SHIFT - 0x04u)

    /* Status Register Bit Masks */
    #define loopTimer_STATUS_TC                       ((uint8)((uint8)0x01u << loopTimer_STATUS_TC_SHIFT))
    #define loopTimer_STATUS_CAPTURE                  ((uint8)((uint8)0x01u << loopTimer_STATUS_CAPTURE_SHIFT))
    /* Interrupt Enable Bit-Mask for interrupt on TC */
    #define loopTimer_STATUS_TC_INT_MASK              ((uint8)((uint8)0x01u << loopTimer_STATUS_TC_INT_MASK_SHIFT))
    /* Interrupt Enable Bit-Mask for interrupt on Capture */
    #define loopTimer_STATUS_CAPTURE_INT_MASK         ((uint8)((uint8)0x01u << loopTimer_STATUS_CAPTURE_INT_MASK_SHIFT))

#else   /* UDB Registers and Register Constants */


    /***************************************
    *           UDB Registers
    ***************************************/

    #define loopTimer_STATUS              (* (reg8 *) loopTimer_TimerUDB_rstSts_stsreg__STATUS_REG )
    #define loopTimer_STATUS_MASK         (* (reg8 *) loopTimer_TimerUDB_rstSts_stsreg__MASK_REG)
    #define loopTimer_STATUS_AUX_CTRL     (* (reg8 *) loopTimer_TimerUDB_rstSts_stsreg__STATUS_AUX_CTL_REG)
    #define loopTimer_CONTROL             (* (reg8 *) loopTimer_TimerUDB_sCTRLReg_SyncCtl_ctrlreg__CONTROL_REG )
    
    #if(loopTimer_Resolution <= 8u) /* 8-bit Timer */
        #define loopTimer_CAPTURE_LSB         (* (reg8 *) loopTimer_TimerUDB_sT8_timerdp_u0__F0_REG )
        #define loopTimer_CAPTURE_LSB_PTR       ((reg8 *) loopTimer_TimerUDB_sT8_timerdp_u0__F0_REG )
        #define loopTimer_PERIOD_LSB          (* (reg8 *) loopTimer_TimerUDB_sT8_timerdp_u0__D0_REG )
        #define loopTimer_PERIOD_LSB_PTR        ((reg8 *) loopTimer_TimerUDB_sT8_timerdp_u0__D0_REG )
        #define loopTimer_COUNTER_LSB         (* (reg8 *) loopTimer_TimerUDB_sT8_timerdp_u0__A0_REG )
        #define loopTimer_COUNTER_LSB_PTR       ((reg8 *) loopTimer_TimerUDB_sT8_timerdp_u0__A0_REG )
    #elif(loopTimer_Resolution <= 16u) /* 8-bit Timer */
        #if(CY_PSOC3) /* 8-bit addres space */
            #define loopTimer_CAPTURE_LSB         (* (reg16 *) loopTimer_TimerUDB_sT8_timerdp_u0__F0_REG )
            #define loopTimer_CAPTURE_LSB_PTR       ((reg16 *) loopTimer_TimerUDB_sT8_timerdp_u0__F0_REG )
            #define loopTimer_PERIOD_LSB          (* (reg16 *) loopTimer_TimerUDB_sT8_timerdp_u0__D0_REG )
            #define loopTimer_PERIOD_LSB_PTR        ((reg16 *) loopTimer_TimerUDB_sT8_timerdp_u0__D0_REG )
            #define loopTimer_COUNTER_LSB         (* (reg16 *) loopTimer_TimerUDB_sT8_timerdp_u0__A0_REG )
            #define loopTimer_COUNTER_LSB_PTR       ((reg16 *) loopTimer_TimerUDB_sT8_timerdp_u0__A0_REG )
        #else /* 16-bit address space */
            #define loopTimer_CAPTURE_LSB         (* (reg16 *) loopTimer_TimerUDB_sT8_timerdp_u0__16BIT_F0_REG )
            #define loopTimer_CAPTURE_LSB_PTR       ((reg16 *) loopTimer_TimerUDB_sT8_timerdp_u0__16BIT_F0_REG )
            #define loopTimer_PERIOD_LSB          (* (reg16 *) loopTimer_TimerUDB_sT8_timerdp_u0__16BIT_D0_REG )
            #define loopTimer_PERIOD_LSB_PTR        ((reg16 *) loopTimer_TimerUDB_sT8_timerdp_u0__16BIT_D0_REG )
            #define loopTimer_COUNTER_LSB         (* (reg16 *) loopTimer_TimerUDB_sT8_timerdp_u0__16BIT_A0_REG )
            #define loopTimer_COUNTER_LSB_PTR       ((reg16 *) loopTimer_TimerUDB_sT8_timerdp_u0__16BIT_A0_REG )
        #endif /* CY_PSOC3 */
    #elif(loopTimer_Resolution <= 24u)/* 24-bit Timer */
        #define loopTimer_CAPTURE_LSB         (* (reg32 *) loopTimer_TimerUDB_sT8_timerdp_u0__F0_REG )
        #define loopTimer_CAPTURE_LSB_PTR       ((reg32 *) loopTimer_TimerUDB_sT8_timerdp_u0__F0_REG )
        #define loopTimer_PERIOD_LSB          (* (reg32 *) loopTimer_TimerUDB_sT8_timerdp_u0__D0_REG )
        #define loopTimer_PERIOD_LSB_PTR        ((reg32 *) loopTimer_TimerUDB_sT8_timerdp_u0__D0_REG )
        #define loopTimer_COUNTER_LSB         (* (reg32 *) loopTimer_TimerUDB_sT8_timerdp_u0__A0_REG )
        #define loopTimer_COUNTER_LSB_PTR       ((reg32 *) loopTimer_TimerUDB_sT8_timerdp_u0__A0_REG )
    #else /* 32-bit Timer */
        #if(CY_PSOC3 || CY_PSOC5) /* 8-bit address space */
            #define loopTimer_CAPTURE_LSB         (* (reg32 *) loopTimer_TimerUDB_sT8_timerdp_u0__F0_REG )
            #define loopTimer_CAPTURE_LSB_PTR       ((reg32 *) loopTimer_TimerUDB_sT8_timerdp_u0__F0_REG )
            #define loopTimer_PERIOD_LSB          (* (reg32 *) loopTimer_TimerUDB_sT8_timerdp_u0__D0_REG )
            #define loopTimer_PERIOD_LSB_PTR        ((reg32 *) loopTimer_TimerUDB_sT8_timerdp_u0__D0_REG )
            #define loopTimer_COUNTER_LSB         (* (reg32 *) loopTimer_TimerUDB_sT8_timerdp_u0__A0_REG )
            #define loopTimer_COUNTER_LSB_PTR       ((reg32 *) loopTimer_TimerUDB_sT8_timerdp_u0__A0_REG )
        #else /* 32-bit address space */
            #define loopTimer_CAPTURE_LSB         (* (reg32 *) loopTimer_TimerUDB_sT8_timerdp_u0__32BIT_F0_REG )
            #define loopTimer_CAPTURE_LSB_PTR       ((reg32 *) loopTimer_TimerUDB_sT8_timerdp_u0__32BIT_F0_REG )
            #define loopTimer_PERIOD_LSB          (* (reg32 *) loopTimer_TimerUDB_sT8_timerdp_u0__32BIT_D0_REG )
            #define loopTimer_PERIOD_LSB_PTR        ((reg32 *) loopTimer_TimerUDB_sT8_timerdp_u0__32BIT_D0_REG )
            #define loopTimer_COUNTER_LSB         (* (reg32 *) loopTimer_TimerUDB_sT8_timerdp_u0__32BIT_A0_REG )
            #define loopTimer_COUNTER_LSB_PTR       ((reg32 *) loopTimer_TimerUDB_sT8_timerdp_u0__32BIT_A0_REG )
        #endif /* CY_PSOC3 || CY_PSOC5 */ 
    #endif

    #define loopTimer_COUNTER_LSB_PTR_8BIT       ((reg8 *) loopTimer_TimerUDB_sT8_timerdp_u0__A0_REG )
    
    #if (loopTimer_UsingHWCaptureCounter)
        #define loopTimer_CAP_COUNT              (*(reg8 *) loopTimer_TimerUDB_sCapCount_counter__PERIOD_REG )
        #define loopTimer_CAP_COUNT_PTR          ( (reg8 *) loopTimer_TimerUDB_sCapCount_counter__PERIOD_REG )
        #define loopTimer_CAPTURE_COUNT_CTRL     (*(reg8 *) loopTimer_TimerUDB_sCapCount_counter__CONTROL_AUX_CTL_REG )
        #define loopTimer_CAPTURE_COUNT_CTRL_PTR ( (reg8 *) loopTimer_TimerUDB_sCapCount_counter__CONTROL_AUX_CTL_REG )
    #endif /* (loopTimer_UsingHWCaptureCounter) */


    /***************************************
    *       Register Constants
    ***************************************/

    /* Control Register Bit Locations */
    #define loopTimer_CTRL_INTCNT_SHIFT              0x00u       /* As defined by Verilog Implementation */
    #define loopTimer_CTRL_TRIG_MODE_SHIFT           0x02u       /* As defined by Verilog Implementation */
    #define loopTimer_CTRL_TRIG_EN_SHIFT             0x04u       /* As defined by Verilog Implementation */
    #define loopTimer_CTRL_CAP_MODE_SHIFT            0x05u       /* As defined by Verilog Implementation */
    #define loopTimer_CTRL_ENABLE_SHIFT              0x07u       /* As defined by Verilog Implementation */

    /* Control Register Bit Masks */
    #define loopTimer_CTRL_INTCNT_MASK               ((uint8)((uint8)0x03u << loopTimer_CTRL_INTCNT_SHIFT))
    #define loopTimer_CTRL_TRIG_MODE_MASK            ((uint8)((uint8)0x03u << loopTimer_CTRL_TRIG_MODE_SHIFT))
    #define loopTimer_CTRL_TRIG_EN                   ((uint8)((uint8)0x01u << loopTimer_CTRL_TRIG_EN_SHIFT))
    #define loopTimer_CTRL_CAP_MODE_MASK             ((uint8)((uint8)0x03u << loopTimer_CTRL_CAP_MODE_SHIFT))
    #define loopTimer_CTRL_ENABLE                    ((uint8)((uint8)0x01u << loopTimer_CTRL_ENABLE_SHIFT))

    /* Bit Counter (7-bit) Control Register Bit Definitions */
    /* As defined by the Register map for the AUX Control Register */
    #define loopTimer_CNTR_ENABLE                    0x20u

    /* Status Register Bit Locations */
    #define loopTimer_STATUS_TC_SHIFT                0x00u  /* As defined by Verilog Implementation */
    #define loopTimer_STATUS_CAPTURE_SHIFT           0x01u  /* As defined by Verilog Implementation */
    #define loopTimer_STATUS_TC_INT_MASK_SHIFT       loopTimer_STATUS_TC_SHIFT
    #define loopTimer_STATUS_CAPTURE_INT_MASK_SHIFT  loopTimer_STATUS_CAPTURE_SHIFT
    #define loopTimer_STATUS_FIFOFULL_SHIFT          0x02u  /* As defined by Verilog Implementation */
    #define loopTimer_STATUS_FIFONEMP_SHIFT          0x03u  /* As defined by Verilog Implementation */
    #define loopTimer_STATUS_FIFOFULL_INT_MASK_SHIFT loopTimer_STATUS_FIFOFULL_SHIFT

    /* Status Register Bit Masks */
    /* Sticky TC Event Bit-Mask */
    #define loopTimer_STATUS_TC                      ((uint8)((uint8)0x01u << loopTimer_STATUS_TC_SHIFT))
    /* Sticky Capture Event Bit-Mask */
    #define loopTimer_STATUS_CAPTURE                 ((uint8)((uint8)0x01u << loopTimer_STATUS_CAPTURE_SHIFT))
    /* Interrupt Enable Bit-Mask */
    #define loopTimer_STATUS_TC_INT_MASK             ((uint8)((uint8)0x01u << loopTimer_STATUS_TC_SHIFT))
    /* Interrupt Enable Bit-Mask */
    #define loopTimer_STATUS_CAPTURE_INT_MASK        ((uint8)((uint8)0x01u << loopTimer_STATUS_CAPTURE_SHIFT))
    /* NOT-Sticky FIFO Full Bit-Mask */
    #define loopTimer_STATUS_FIFOFULL                ((uint8)((uint8)0x01u << loopTimer_STATUS_FIFOFULL_SHIFT))
    /* NOT-Sticky FIFO Not Empty Bit-Mask */
    #define loopTimer_STATUS_FIFONEMP                ((uint8)((uint8)0x01u << loopTimer_STATUS_FIFONEMP_SHIFT))
    /* Interrupt Enable Bit-Mask */
    #define loopTimer_STATUS_FIFOFULL_INT_MASK       ((uint8)((uint8)0x01u << loopTimer_STATUS_FIFOFULL_SHIFT))

    #define loopTimer_STATUS_ACTL_INT_EN             0x10u   /* As defined for the ACTL Register */

    /* Datapath Auxillary Control Register definitions */
    #define loopTimer_AUX_CTRL_FIFO0_CLR             0x01u   /* As defined by Register map */
    #define loopTimer_AUX_CTRL_FIFO1_CLR             0x02u   /* As defined by Register map */
    #define loopTimer_AUX_CTRL_FIFO0_LVL             0x04u   /* As defined by Register map */
    #define loopTimer_AUX_CTRL_FIFO1_LVL             0x08u   /* As defined by Register map */
    #define loopTimer_STATUS_ACTL_INT_EN_MASK        0x10u   /* As defined for the ACTL Register */

#endif /* Implementation Specific Registers and Register Constants */

#endif  /* CY_Timer_v2_30_loopTimer_H */


/* [] END OF FILE */
