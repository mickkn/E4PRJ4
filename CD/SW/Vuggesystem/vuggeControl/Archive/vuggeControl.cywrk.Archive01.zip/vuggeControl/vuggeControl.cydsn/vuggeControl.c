/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/

// Libraries
#include "vuggeControl.h"

// ISR attributes


// ISR rutines



int main()
{
    // Initialization
    
   
    

    /* CyGlobalIntEnable; */ /* Uncomment this line to enable global interrupts. */
    for(;;)
    {
        /* Place your application code here. */
    }
}

void sendConKom(char* onoffPtr, char* frekvensPtr, char* vinkeludsvingPtr)
{

}
void reguleringsStatus(BOOL bool)
{

}

void lukSystem()
{
    
}

void checkEndstop(BOOL bool)
{
    
}


/* [] END OF FILE */
