/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#ifndef LIBSVUGGESYSTEM_H
#define LIBSVUGGESYSTEM_H

// Libraries
#include <project.h>
#include <stdio.h>
#include <stdlib.h>
#include <cytypes.h>

// Global definitons
#define FALSE 0
#define TRUE !FALSE

typedef uint8 BOOL;

#endif
/* [] END OF FILE */
