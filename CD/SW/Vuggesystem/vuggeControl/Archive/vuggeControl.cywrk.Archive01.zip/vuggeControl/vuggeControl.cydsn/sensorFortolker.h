/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#ifndef SENSORFORTOLKER_H
#define SENSORFORTOLKER_H

//Libraries
#include "LIBSVuggeSystem.h"


// Definitions
#define SIZESF 6


// Attributes
char vuggeudsvingArray_[SIZESF];
int sensorData_[SIZESF];
char* vuggeudsvingArrayPtr_;
int* sfSensorDataPtr_;
BOOL endstop_;

// Prototype functions
void initSensor();
void getMotorPosSens();
void getVuggeUdsvingSens();
void calcAbsVuggeUdsving(char*);
int* getSensorData();
void endstopGPIO(BOOL);



#endif
/* [] END OF FILE */
