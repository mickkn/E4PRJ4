/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/

// Libraries
#include "regulering.h"

// Function declarations
void initRegulering()
{

}

void regParameter(char vuggefrekvens, char vuggeudsving)
{

}

void PWMStyring(int fixedPointReg)
{

}



/* [] END OF FILE */
