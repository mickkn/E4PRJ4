/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/

// Libraries
#include "i2cKommunikation.h"

// Function declarations
void initI2C(void)
{
    
}

void setConKom(char regStatus)
{

}

void sendI2C(char sendRegStatus)
{
    
}




/* [] END OF FILE */
