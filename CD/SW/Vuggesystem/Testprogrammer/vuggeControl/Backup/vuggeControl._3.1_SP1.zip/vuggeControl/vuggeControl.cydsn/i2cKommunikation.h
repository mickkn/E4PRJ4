/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/

// Definitions
#ifndef I2CKOMMUNIKATION_H
#define I2CKOMMUNIKATION_H
    
//Libraries    
#include "LIBSVuggeSystem.h"



#define I2C_ID_REG 0x00
#define I2C_STAT_REG 0x01
#define I2C_ONOFF_REG 0x02
#define I2C_FREK_REG 0x03
#define I2C_VINK_REG 0x04 
#define I2C_BUF_SIZE (0x05u)
#define DEBUG 1
#define I2C_DEV_ADDR (0x08)

// Attributes
uint8 I2CRegPtr = 0;
uint8 reg[I2C_BUF_SIZE]= {1, 2, 3, 4, 5};//{0xFB, 0x00, 0xFF, 0x00, 0x00};
uint8 I2CRxBuf[I2C_BUF_SIZE] = {11, 12, 13, 14, 15};

// Prototype functions
void initI2C(void);
void setConKom(char regStatus);
void sendI2C(char sendRegStatus);


#endif
/* [] END OF FILE */
