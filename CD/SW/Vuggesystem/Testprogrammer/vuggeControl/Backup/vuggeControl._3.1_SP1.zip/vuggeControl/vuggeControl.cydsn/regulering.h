/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/

// Definitions
#ifndef REGULERING_H
#define REGULERING_H

// Libraries
#include "LIBSVuggeSystem.h"




// Attributes
char vuggefrekvens_;
char vuggeudsving_;
int* sensorDataPtr_;
int fixedPointReg_;

// Prototype functions
void initRegulering();
void regParameter(char, char);
void PWMStyring(int);


#endif
/* [] END OF FILE */
