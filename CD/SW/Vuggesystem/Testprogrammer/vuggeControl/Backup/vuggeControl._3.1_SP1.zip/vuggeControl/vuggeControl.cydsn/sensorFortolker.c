/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
// Libraries
#include "SensorFortolker.h"


// Function declarations
void initSensor()
{

}

void getMotorPosSens()
{

}

void getVuggeUdsvingSens()
{

}

void calcAbsVuggeUdsving(char* vuggeudsvingArrayPtr)
{

}


int* getSensorData()
{
    
return NULL;
}


void endstopGPIO(BOOL ESSwitch)
{

}







/* [] END OF FILE */
