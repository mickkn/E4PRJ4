/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#ifndef VUGGECONTROL_H
#define VUGGECONTROL_H

// Libraries
#include "LIBSVuggeSystem.h"

// Definitions


// Attributes
BOOL endstopStatus_ = FALSE;
char reguleringsStatus_ = 0;
char* onoffPtr_;
char* frekvensPtr_;
char* vinkeludsvingPtr_;

// Prototype functions
void sendConKom(char* onoffPtr, char* frekvensPtr, char* vinkeludsvingPtr);
void reguleringsStatus(BOOL);
void lukSystem(void);
void checkEndstop(BOOL);


#endif
/* [] END OF FILE */
